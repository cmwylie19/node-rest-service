package negotiator

import "errors"

var ErrNoMatchingResponse = errors.New("no matching response found")
