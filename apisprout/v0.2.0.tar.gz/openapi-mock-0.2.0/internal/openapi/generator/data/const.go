package data

const (
	defaultMaxLength = 200
	defaultMaxItems  = 20
)
