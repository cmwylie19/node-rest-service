package data

type recursiveGenerator interface {
	SetSchemaGenerator(schemaGenerator schemaGenerator)
}
