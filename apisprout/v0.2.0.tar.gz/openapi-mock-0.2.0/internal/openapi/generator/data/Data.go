package data

type Data interface{}
