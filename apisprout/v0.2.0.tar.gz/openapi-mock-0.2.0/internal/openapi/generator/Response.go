package generator

type Response struct {
	StatusCode  int
	ContentType string
	Data        interface{}
}
